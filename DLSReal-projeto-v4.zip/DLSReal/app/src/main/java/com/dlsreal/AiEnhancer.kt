package com.dlsreal

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.roundToInt

/**
 * Modo IA: roda um modelo .tflite imagem->imagem (float32, NHWC, 0..1, saída com o mesmo
 * tamanho da entrada) numa thread própria. Entrega só a DIFERENÇA (saída - entrada) em RGBA8
 * (128 = sem mudança); o shader soma essa diferença ao quadro em resolução total.
 */
class AiEnhancer(private val ctx: Context) {

    companion object {
        const val MODEL_FILE = "enhancer.tflite"
        const val RANGE = 0.35f // faixa da diferença codificada (o shader usa o mesmo valor)
        private const val TAG = "DLSReal-IA"
        fun modelFile(ctx: Context) = File(ctx.filesDir, MODEL_FILE)
        fun hasModel(ctx: Context) = modelFile(ctx).let { it.exists() && it.length() > 0 }
    }

    @Volatile var ready = false
        private set
    @Volatile var failed: String? = null
        private set
    @Volatile var busy = false
        private set
    @Volatile var resultReady = false
        private set
    @Volatile var inW = 0
        private set
    @Volatile var inH = 0
        private set
    lateinit var pixels: ByteBuffer // entrada RGBA (linhas de baixo p/ cima, como o glReadPixels)
        private set
    lateinit var delta: ByteBuffer  // saída RGBA (mesma ordem, pronta p/ textura GL)
        private set
    var onResult: (() -> Unit)? = null

    private val thread = HandlerThread("dlsreal-ai").apply { start() }
    private val bg = Handler(thread.looper)
    private var interp: Interpreter? = null
    private var gpu: GpuDelegate? = null
    private var inBuf: ByteBuffer? = null
    private var outBuf: ByteBuffer? = null
    @Volatile private var closed = false

    fun start(capW: Int, capH: Int) {
        bg.post {
            try {
                load(capW, capH)
            } catch (t: Throwable) {
                Log.e(TAG, "falha ao carregar", t)
                failed = "Não consegui carregar o modelo de IA: ${t.message}"
            }
        }
    }

    private fun cpuOptions() = Interpreter.Options().setNumThreads(4)

    private fun load(capW: Int, capH: Int) {
        val file = modelFile(ctx)
        val map = FileInputStream(file).use { it.channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length()) }

        var ip: Interpreter? = null
        try {
            val cl = CompatibilityList()
            if (cl.isDelegateSupportedOnThisDevice) {
                val d = GpuDelegate(cl.bestOptionsForThisDevice)
                try {
                    ip = Interpreter(map, Interpreter.Options().addDelegate(d))
                    gpu = d
                } catch (t: Throwable) { d.close(); ip = null }
            }
        } catch (t: Throwable) { ip = null }
        if (ip == null) ip = Interpreter(map, cpuOptions())

        // modelo com tamanho dinâmico: usa CPU e escolhe um tamanho pela proporção da tela
        if (ip.getInputTensor(0).shapeSignature().any { it < 0 }) {
            if (gpu != null) { ip.close(); gpu?.close(); gpu = null; ip = Interpreter(map, cpuOptions()) }
            val longSide = 384
            val w: Int; val h: Int
            if (capW >= capH) { w = longSide; h = maxOf(64, (longSide * capH / capW) and -8) }
            else { h = longSide; w = maxOf(64, (longSide * capW / capH) and -8) }
            ip.resizeInput(0, intArrayOf(1, h, w, 3))
            ip.allocateTensors()
        }

        val ts = ip.getInputTensor(0)
        val shape = ts.shape()
        if (ts.dataType() != DataType.FLOAT32 || shape.size != 4 || shape[3] != 3) {
            ip.close(); gpu?.close()
            failed = "O modelo precisa ter entrada float32 [1,altura,largura,3]."
            return
        }
        val os = ip.getOutputTensor(0)
        if (os.dataType() != DataType.FLOAT32 || !os.shape().contentEquals(shape)) {
            ip.close(); gpu?.close()
            failed = "A saída do modelo precisa ter o mesmo formato da entrada."
            return
        }
        val h = shape[1]; val w = shape[2]
        inBuf = ByteBuffer.allocateDirect(w * h * 3 * 4).order(ByteOrder.nativeOrder())
        outBuf = ByteBuffer.allocateDirect(w * h * 3 * 4).order(ByteOrder.nativeOrder())
        pixels = ByteBuffer.allocateDirect(w * h * 4)
        delta = ByteBuffer.allocateDirect(w * h * 4)
        interp = ip
        inW = w; inH = h
        Log.i(TAG, "modelo pronto ${w}x$h, GPU=${gpu != null}")
        ready = true
        if (closed) release()
    }

    /** Chamado pela thread GL depois de preencher [pixels]. */
    fun submit() {
        if (!ready || closed || busy) return
        busy = true
        bg.post {
            try { infer() } catch (t: Throwable) {
                Log.e(TAG, "erro na inferência", t)
                failed = "Erro ao rodar a IA: ${t.message}"
                busy = false
            }
        }
    }

    /** Chamado pela thread GL depois de subir [delta] para a textura. */
    fun consumed() { resultReady = false; busy = false }

    private fun infer() {
        val ip = interp ?: run { busy = false; return }
        val w = inW; val h = inH
        val ib = inBuf!!; val ob = outBuf!!
        val px = pixels; val dl = delta
        val inF = ib.asFloatBuffer()
        for (y in 0 until h) {
            val src = (h - 1 - y) * w * 4 // GL entrega a linha de baixo primeiro
            var o = y * w * 3
            for (x in 0 until w) {
                val s = src + x * 4
                inF.put(o++, (px.get(s).toInt() and 255) / 255f)
                inF.put(o++, (px.get(s + 1).toInt() and 255) / 255f)
                inF.put(o++, (px.get(s + 2).toInt() and 255) / 255f)
            }
        }
        ib.rewind(); ob.rewind()
        ip.run(ib, ob)
        ob.rewind()
        val of = ob.asFloatBuffer()
        for (y in 0 until h) {
            val dst = (h - 1 - y) * w * 4
            var o = y * w * 3
            for (x in 0 until w) {
                val s = dst + x * 4
                for (c in 0 until 3) {
                    val inp = (px.get(s + c).toInt() and 255) / 255f
                    val dv = (of.get(o + c) - inp).coerceIn(-RANGE, RANGE)
                    dl.put(s + c, (128 + dv / RANGE * 127f).roundToInt().coerceIn(1, 255).toByte())
                }
                dl.put(s + 3, 255.toByte())
                o += 3
            }
        }
        resultReady = true
        onResult?.invoke()
    }

    private fun release() {
        runCatching { interp?.close() }
        runCatching { gpu?.close() }
        interp = null; gpu = null
        thread.quitSafely()
    }

    fun close() {
        closed = true
        ready = false
        bg.post { release() }
    }
}
