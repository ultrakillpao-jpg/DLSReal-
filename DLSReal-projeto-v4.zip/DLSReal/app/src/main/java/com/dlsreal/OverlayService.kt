package com.dlsreal

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.dlsreal.STOP"
        private const val CHANNEL = "dlsreal"
        private const val NOTIF_ID = 7
        private const val SCALE = 0.5f // resolução da captura (0.5 = metade; menor = mais leve)
        private const val MODE_AUTO = 0 // liga sozinho só dentro dos jogos escolhidos
        private const val MODE_ON = 1   // sempre ligado
        private const val MODE_OFF = 2  // sempre desligado
        private const val POLL_MS = 800L
        private const val RENDER_SHADER = 0 // modo 1: shaders que se adaptam ao jogo
        private const val RENDER_AI = 1     // modo 2: shaders + IA em cada quadro
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var currentSurface: Surface? = null
    private val renderer = EnhanceRenderer()

    private var glView: GLSurfaceView? = null
    private var tab: LinearLayout? = null
    private var toggle: TextView? = null
    private var active = false   // efeito realmente ligado agora
    private var mode = MODE_AUTO
    private var warnedUsage = false
    private var renderMode = RENDER_SHADER
    private var ai: AiEnhancer? = null
    private var modeBtn: TextView? = null
    private lateinit var tracker: ForegroundTracker
    private val poll = object : Runnable {
        override fun run() { tick(); main.postDelayed(this, POLL_MS) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP || !Settings.canDrawOverlays(this)) {
            stopSelf(); return START_NOT_STICKY
        }
        startAsForeground()
        if (projection == null) {
            val code = intent.getIntExtra("code", 0)
            val data = intent.getParcelableExtra<Intent>("data")
            if (data == null) { stopSelf(); return START_NOT_STICKY }
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mgr.getMediaProjection(code, data)
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
            projection = proj
            buildUi()
        }
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "DLS Real", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("DLS Real ativo")
            .setContentText("Use a aba preta para ligar/desligar")
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Desativar", stop
                ).build()
            )
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun realSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }

    private fun captureSize(): Pair<Int, Int> {
        val (w, h) = realSize()
        return (max(2, (w * SCALE).toInt()) and -2) to (max(2, (h * SCALE).toInt()) and -2)
    }

    private fun buildUi() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("dlsreal", MODE_PRIVATE)

        val (cw, ch) = captureSize()
        renderer.capW = cw; renderer.capH = ch
        applyPrefs()

        // ---- camada dos shaders (tela cheia, toques passam para o jogo) ----
        val gv = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setEGLConfigChooser(8, 8, 8, 8, 0, 0)
            holder.setFormat(PixelFormat.TRANSLUCENT)
            holder.setFixedSize(cw, ch) // camada no mesmo tamanho da captura (permite cancelar a realimentação)
            setZOrderOnTop(true)
            preserveEGLContextOnPause = true
        }
        renderer.requestRender = { gv.requestRender() }
        renderer.onSurface = { s -> main.post { attachSurface(s) } }
        gv.setRenderer(renderer)
        gv.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY

        val glLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            glLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(gv, glLp)
        glView = gv

        // ---- aba preta pequena ----
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EE000000"))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            }
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tg = TextView(this).apply {
            textSize = 13f
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        toggle = tg
        val gear = TextView(this).apply {
            text = "⚙"; textSize = 16f; setTextColor(Color.WHITE)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val close = TextView(this).apply {
            text = "✕"; textSize = 14f; setTextColor(Color.parseColor("#FF6B6B"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { stopSelf() }
        }
        row.addView(tg); row.addView(gear); row.addView(close)
        root.addView(row)

        val panel = buildPanel()
        root.addView(panel)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("tabX", dp(8))
            y = prefs.getInt("tabY", dp(120))
        }
        gear.setOnClickListener {
            panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            wm.updateViewLayout(root, lp)
        }
        tab = root

        // arrastar pelo OFF/ON; toque simples liga/desliga
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        tg.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) { lp.x = startX + dx; lp.y = startY + dy; wm.updateViewLayout(root, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs.edit().putInt("tabX", lp.x).putInt("tabY", lp.y).apply()
                    else cycleMode()
                    true
                }
                else -> false
            }
        }
        wm.addView(root, lp)
        mode = prefs.getInt("mode", MODE_AUTO)
        tracker = ForegroundTracker(this)
        setActive(mode == MODE_ON)
        if (mode == MODE_AUTO) {
            val g = prefs.getStringSet("games", emptySet()) ?: emptySet()
            if (g.isEmpty()) {
                Toast.makeText(this, "Escolha os jogos no app DLS Real para o AUTO funcionar (ou toque no rótulo para ligar manual).", Toast.LENGTH_LONG).show()
            }
        }
        setRenderMode(prefs.getInt("render", RENDER_SHADER), false)
        main.postDelayed(poll, 300)
    }

    /** Chamado quando o GL cria a superfície que recebe a captura da tela. */
    private fun attachSurface(surface: Surface) {
        val proj = projection ?: return
        currentSurface = surface
        val (w, h) = captureSize()
        val dpi = resources.displayMetrics.densityDpi
        val existing = vd
        if (existing == null) {
            vd = proj.createVirtualDisplay(
                "dlsreal", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                if (active) surface else null, null, null
            )
        } else {
            existing.surface = if (active) surface else null
        }
    }

    private fun setActive(v: Boolean) {
        active = v
        renderer.enabled = v
        vd?.surface = if (v) currentSurface else null // pausa a captura quando desligado
        glView?.requestRender()
        updateLabel()
    }

    private fun updateLabel() {
        val txt: String
        val col: String
        when (mode) {
            MODE_ON -> { txt = "● ON"; col = "#4CAF50" }
            MODE_OFF -> { txt = "● OFF"; col = "#9E9E9E" }
            else -> if (active) { txt = "● AUTO ✓"; col = "#4CAF50" } else { txt = "● AUTO"; col = "#FFB74D" }
        }
        toggle?.apply {
            text = if (renderMode == RENDER_AI) "$txt · IA" else txt
            setTextColor(Color.parseColor(col))
            setTypeface(typeface, Typeface.BOLD)
        }
    }

    /** Toque no rótulo: AUTO -> ON -> OFF -> AUTO */
    private fun cycleMode() {
        mode = (mode + 1) % 3
        prefs.edit().putInt("mode", mode).apply()
        when (mode) {
            MODE_ON -> { setActive(true); Toast.makeText(this, "Sempre ligado", Toast.LENGTH_SHORT).show() }
            MODE_OFF -> { setActive(false); Toast.makeText(this, "Desligado", Toast.LENGTH_SHORT).show() }
            else -> {
                setActive(false)
                Toast.makeText(this, "Automático: liga só nos jogos escolhidos", Toast.LENGTH_SHORT).show()
                tick()
            }
        }
        updateLabel()
    }

    /** Modo AUTO: liga só quando o app em primeiro plano é um dos jogos escolhidos. */
    private fun tick() {
        ai?.failed?.let { msg ->
            Toast.makeText(this, "$msg\nVoltando para o modo Shaders.", Toast.LENGTH_LONG).show()
            setRenderMode(RENDER_SHADER)
        }
        if (mode != MODE_AUTO) return
        val games = prefs.getStringSet("games", emptySet()) ?: emptySet()
        var want = false
        if (!UsageAccess.granted(this)) {
            if (!warnedUsage) {
                warnedUsage = true
                Toast.makeText(this, "O AUTO precisa de \"Acesso de uso\". Abra o app DLS Real e toque em Permitir.", Toast.LENGTH_LONG).show()
            }
        } else if (games.isNotEmpty()) {
            val fg = runCatching { tracker.current() }.getOrNull()
            want = fg != null && fg in games
        }
        if (want != active) setActive(want)
    }

    private fun applyPrefs() {
        renderer.ao = prefs.getInt("ao", 60) / 60f
        renderer.spec = prefs.getInt("spec", 60) / 60f
        renderer.refl = prefs.getInt("refl", 60) / 60f
        renderer.lightK = prefs.getInt("light", 60) / 60f
        renderer.metal = prefs.getInt("metal", 60) / 60f
        renderer.lamp = prefs.getInt("lamp", 60) / 60f
        renderer.aiK = prefs.getInt("aiK", 60) / 100f
    }

    /** Troca entre modo Shaders e modo IA por quadro. */
    private fun setRenderMode(m: Int, persist: Boolean = true) {
        var target = m
        if (target == RENDER_AI && !AiEnhancer.hasModel(this)) {
            Toast.makeText(this, "O modo IA precisa de um modelo .tflite: abra o app DLS Real e toque em Importar modelo de IA.", Toast.LENGTH_LONG).show()
            target = RENDER_SHADER
        }
        renderMode = target
        if (persist) prefs.edit().putInt("render", target).apply()
        if (target == RENDER_AI) {
            if (ai == null) {
                val e = AiEnhancer(this)
                e.onResult = { glView?.requestRender() }
                ai = e
                renderer.ai = e
                e.start(renderer.capW, renderer.capH)
            }
        } else {
            renderer.ai = null
            ai?.close()
            ai = null
        }
        modeBtn?.text = if (renderMode == RENDER_AI) "Modo: IA por quadro (toque p/ trocar)" else "Modo: Shaders (toque p/ trocar)"
        updateLabel()
    }

    private fun buildPanel(): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            minimumWidth = dp(240)
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        val mb = TextView(this).apply {
            textSize = 12f; setTextColor(Color.parseColor("#4FC3F7"))
            setPadding(0, dp(4), 0, dp(4))
            setOnClickListener { setRenderMode(if (renderMode == RENDER_AI) RENDER_SHADER else RENDER_AI) }
        }
        modeBtn = mb
        box.addView(mb)
        box.addView(seekRow("Intensidade da IA", "aiK") { renderer.aiK = it / 100f })
        box.addView(seekRow("Sombras de contato", "ao") { renderer.ao = it / 60f })
        box.addView(seekRow("Brilho / metal / detalhe", "spec") { renderer.spec = it / 60f })
        box.addView(seekRow("Reflexo chão / água", "refl") { renderer.refl = it / 60f })
        box.addView(seekRow("Luz dinâmica / cor", "light") { renderer.lightK = it / 60f })
        box.addView(seekRow("Metal (brilho / reflexo)", "metal") { renderer.metal = it / 60f })
        box.addView(seekRow("Lâmpadas / halo de luz", "lamp") { renderer.lamp = it / 60f })
        box.addView(TextView(this).apply {
            text = "Toque no rótulo: AUTO → ON → OFF"
            textSize = 10f; setTextColor(Color.parseColor("#888888"))
            setPadding(0, dp(8), 0, 0)
        })
        return box
    }

    private fun seekRow(label: String, key: String, onChange: (Int) -> Unit): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, 0) }
        col.addView(TextView(this).apply {
            text = label; textSize = 11f; setTextColor(Color.parseColor("#BBBBBB"))
        })
        col.addView(SeekBar(this).apply {
            max = 100; progress = prefs.getInt(key, 60)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { prefs.edit().putInt(key, s.progress).apply() }
            })
        })
        return col
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (projection == null) return
        main.postDelayed({
            val (w, h) = captureSize()
            renderer.resize(w, h)
            glView?.holder?.setFixedSize(w, h)
            runCatching { vd?.resize(w, h, resources.displayMetrics.densityDpi) }
        }, 300)
    }

    override fun onDestroy() {
        main.removeCallbacks(poll)
        renderer.ai = null
        runCatching { ai?.close() }
        ai = null
        runCatching { vd?.release() }
        runCatching { projection?.stop() }
        runCatching { glView?.let { wm.removeView(it) } }
        runCatching { tab?.let { wm.removeView(it) } }
        vd = null; projection = null; glView = null; tab = null
        super.onDestroy()
    }
}
