# Modo IA por quadro: modelo .tflite

No app DLS Real toque em "Importar modelo de IA (.tflite)" e escolha o arquivo.

Formato aceito (imagem -> imagem):
- entrada float32, formato [1, altura, largura, 3], valores de 0 a 1 (RGB)
- saída float32 com o MESMO formato da entrada, também de 0 a 1
- tamanho fixo (ex.: 256x448) roda na GPU; tamanho dinâmico roda na CPU (mais lento)

A rede roda numa resolução pequena e só a DIFERENÇA (saída - entrada) é somada
ao quadro em resolução total, por cima dos shaders. Ajuste em "Intensidade da IA" (aba ⚙).
